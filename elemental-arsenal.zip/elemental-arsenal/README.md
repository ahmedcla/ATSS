# Elemental Arsenal (ترسانة العناصر)

مود Fabric لنسخة **Minecraft 1.21.11** فيه 4 سيوف + 4 أطقم دروع (نار، جليد، رياح، أرض).

## شلون تبنيه على GitHub (بدون ما تنزّل أي شي على جهازك)

1. افتح github.com وسجّل دخول (سوي حساب مجاني إذا ما عندك).
2. اضغط **New repository**، سمّيه `elemental-arsenal`، واضغط **Create repository**.
3. اضغط **uploading an existing file**، واسحب **كل محتويات** هذا المجلد (بعد ما تفك الـ zip) داخل الصفحة:
   `src` و `gradle` و `.github` و `build.gradle` و `gradle.properties` و `settings.gradle` و `gradlew` و `gradlew.bat` و `LICENSE` و `.gitignore`.
   اضغط **Commit changes**.
4. **مهم:** تأكد أن مجلد `.github` انرفع (بيه ملف `workflows/build.yml`). إذا ما انرفع (لأن بعض الأجهزة تخفي المجلدات اللي تبدأ بنقطة):
   اضغط **Add file → Create new file**، اكتب بخانة الاسم `.github/workflows/build.yml` والصق محتوى الملف نفسه، واضغط Commit.
5. اضغط تبويب **Actions**. راح تشوف "Build mod" يشتغل (ياخذ 3-6 دقايق). إذا ما اشتغل لحاله اضغط عليه ثم **Run workflow**.
6. لما يصير أخضر ✓ افتحه، ونزّل من تحت **Artifacts** الملف `elementalarsenal-jar`. افتحه وبيه `elementalarsenal-1.0.0.jar`.
7. حطّ الـ jar بمجلد `mods` بالسيرفر **وعند كل لاعب** (مع Fabric API). نفس نسخة Element Powers: Fabric 1.21.11.

إذا طلع الـ Build أحمر ✗: افتحه وانسخلي الأسطر الحمرا من الـ log وأنا أصلحها.

## كيف تجيب الأغراض

- من التاب الإبداعي **Elemental Arsenal**.
- أو بالأوامر (للأدمن): `/give @s elementalarsenal:fire_sword`
- أو طقم كامل بأمر واحد: `/function elementalarsenal:fire` (أو `ice` أو `wind` أو `earth` أو `all` للكل).

أسماء الأغراض: `fire_sword` `fire_helmet` `fire_chestplate` `fire_leggings` `fire_boots` وهكذا لكل عنصر (`ice_` `wind_` `earth_`).

## المواصفات

| السيف | الدمج | الخاصية |
|---|---|---|
| سيف النار | 12 (15 ضد دروع الجليد) | Fire Aspect V: يحرق 20 ثانية |
| سيف الجليد | 12 (15 ضد دروع النار) | يجمّد الهدف داخل مكعب جليد + Slowness + شاشة التجمد |
| سيف الهواء | 12 | Knockback 3 |
| سيف الأرض | 12 | Strength 2 طول ما شايله بيدك |

| الدروع | الخوذة | الصدرية | البنطلون | الحذاء | الخاصية |
|---|---|---|---|---|---|
| النار | 5 | 8 | 6 | 5 | Fire Resistance (الطقم كامل) |
| الجليد | 5 | 8 | 6 | 5 | مناعة من الجليد والتجمد (الطقم كامل) |
| الهواء | 5 | 8 | 6 | 5 | بدون ضرر السقوط (الحذاء بس) |
| الأرض | 5 | 8 | 6 | 5 | Resistance 2 (الطقم كامل) |

ملاحظات:
- الدمج 15 يتحسب كـ12 + 3 دمج إضافي، ويصير لما يلبس الخصم **قطعة وحدة على الأقل** من الدرع المعاكس.
- سيف الأرض: Strength 2 يزيد +6 دمج فوق الـ12 طول ما شايله.
- الدروع نفس صلابة Netherite (toughness 3). إصلاحها بالسندان بسبيكة Netherite.
- المناعة والتأثيرات اللي تشتغل بالطقم تحتاج **الأربع قطع** لابسها.

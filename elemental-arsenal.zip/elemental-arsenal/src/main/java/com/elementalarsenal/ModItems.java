package com.elementalarsenal;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.ChatFormatting;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;

public final class ModItems {
	private ModItems() {
	}

	/** Every item of the mod, in creative-tab order. */
	private static final List<Item> ALL = new ArrayList<>();

	// Attack damage passed to Item.Properties#sword. Total damage = 1 (player base) + this = 12.
	private static final float SWORD_DAMAGE = 11.0F;
	private static final float SWORD_SPEED = -2.4F;

	// ---------------------------------------------------------------- swords
	public static final Item FIRE_SWORD = sword("fire_sword", ChatFormatting.GOLD,
			"Fire Aspect V", "Sets enemies ablaze for 20 seconds", "+3 damage against Ice armor");
	public static final Item ICE_SWORD = sword("ice_sword", ChatFormatting.AQUA,
			"Freezes enemies in a shell of ice", "Slowness + freezing", "+3 damage against Fire armor");
	public static final Item WIND_SWORD = sword("wind_sword", ChatFormatting.WHITE,
			"Knockback III", "Blows enemies away");
	public static final Item EARTH_SWORD = sword("earth_sword", ChatFormatting.GREEN,
			"Strength II while held", "The strength of the mountain");

	// ---------------------------------------------------------------- armor
	public static final Item FIRE_HELMET = armor("fire_helmet", ModMaterials.FIRE_ARMOR, ArmorType.HELMET, ChatFormatting.GOLD, "Full set: Fire Resistance");
	public static final Item FIRE_CHESTPLATE = armor("fire_chestplate", ModMaterials.FIRE_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.GOLD, "Full set: Fire Resistance");
	public static final Item FIRE_LEGGINGS = armor("fire_leggings", ModMaterials.FIRE_ARMOR, ArmorType.LEGGINGS, ChatFormatting.GOLD, "Full set: Fire Resistance");
	public static final Item FIRE_BOOTS = armor("fire_boots", ModMaterials.FIRE_ARMOR, ArmorType.BOOTS, ChatFormatting.GOLD, "Full set: Fire Resistance");

	public static final Item ICE_HELMET = armor("ice_helmet", ModMaterials.ICE_ARMOR, ArmorType.HELMET, ChatFormatting.AQUA, "Full set: immune to ice and freezing");
	public static final Item ICE_CHESTPLATE = armor("ice_chestplate", ModMaterials.ICE_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.AQUA, "Full set: immune to ice and freezing");
	public static final Item ICE_LEGGINGS = armor("ice_leggings", ModMaterials.ICE_ARMOR, ArmorType.LEGGINGS, ChatFormatting.AQUA, "Full set: immune to ice and freezing");
	public static final Item ICE_BOOTS = armor("ice_boots", ModMaterials.ICE_ARMOR, ArmorType.BOOTS, ChatFormatting.AQUA, "Full set: immune to ice and freezing");

	public static final Item WIND_HELMET = armor("wind_helmet", ModMaterials.WIND_ARMOR, ArmorType.HELMET, ChatFormatting.WHITE, "Boots: no fall damage");
	public static final Item WIND_CHESTPLATE = armor("wind_chestplate", ModMaterials.WIND_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.WHITE, "Boots: no fall damage");
	public static final Item WIND_LEGGINGS = armor("wind_leggings", ModMaterials.WIND_ARMOR, ArmorType.LEGGINGS, ChatFormatting.WHITE, "Boots: no fall damage");
	public static final Item WIND_BOOTS = armor("wind_boots", ModMaterials.WIND_ARMOR, ArmorType.BOOTS, ChatFormatting.WHITE, "No fall damage");

	public static final Item EARTH_HELMET = armor("earth_helmet", ModMaterials.EARTH_ARMOR, ArmorType.HELMET, ChatFormatting.GREEN, "Full set: Resistance II");
	public static final Item EARTH_CHESTPLATE = armor("earth_chestplate", ModMaterials.EARTH_ARMOR, ArmorType.CHESTPLATE, ChatFormatting.GREEN, "Full set: Resistance II");
	public static final Item EARTH_LEGGINGS = armor("earth_leggings", ModMaterials.EARTH_ARMOR, ArmorType.LEGGINGS, ChatFormatting.GREEN, "Full set: Resistance II");
	public static final Item EARTH_BOOTS = armor("earth_boots", ModMaterials.EARTH_ARMOR, ArmorType.BOOTS, ChatFormatting.GREEN, "Full set: Resistance II");

	public static final Item[] FIRE_SET = {FIRE_HELMET, FIRE_CHESTPLATE, FIRE_LEGGINGS, FIRE_BOOTS};
	public static final Item[] ICE_SET = {ICE_HELMET, ICE_CHESTPLATE, ICE_LEGGINGS, ICE_BOOTS};
	public static final Item[] WIND_SET = {WIND_HELMET, WIND_CHESTPLATE, WIND_LEGGINGS, WIND_BOOTS};
	public static final Item[] EARTH_SET = {EARTH_HELMET, EARTH_CHESTPLATE, EARTH_LEGGINGS, EARTH_BOOTS};

	// ---------------------------------------------------------------- creative tab
	public static final ResourceKey<CreativeModeTab> TAB_KEY =
			ResourceKey.create(Registries.CREATIVE_MODE_TAB, ElementalArsenal.id("arsenal"));

	public static final CreativeModeTab TAB = FabricItemGroup.builder()
			.icon(() -> new ItemStack(FIRE_SWORD))
			.title(Component.translatable("itemGroup.elementalarsenal"))
			.displayItems((params, output) -> {
				for (Item item : ALL) {
					output.accept(item);
				}
			})
			.build();

	/** Called from the mod initializer so that the static fields above are registered. */
	public static void init() {
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_KEY, TAB);
	}

	// ---------------------------------------------------------------- helpers
	private static Item sword(String name, ChatFormatting color, String... loreLines) {
		Item.Properties props = new Item.Properties()
				.sword(ModMaterials.SWORD_MATERIAL, SWORD_DAMAGE, SWORD_SPEED)
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(color, loreLines));
		return register(name, Item::new, props);
	}

	private static Item armor(String name, ArmorMaterial material, ArmorType type, ChatFormatting color, String... loreLines) {
		Item.Properties props = new Item.Properties()
				.humanoidArmor(material, type)
				.durability(type.getDurability(ModMaterials.ARMOR_DURABILITY))
				.rarity(Rarity.EPIC)
				.component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true)
				.component(DataComponents.LORE, lore(color, loreLines));
		return register(name, Item::new, props);
	}

	private static ItemLore lore(ChatFormatting color, String... lines) {
		List<Component> out = new ArrayList<>();
		for (String line : lines) {
			out.add(Component.literal(line).withStyle(color));
		}
		return new ItemLore(out);
	}

	private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties props) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, ElementalArsenal.id(name));
		T item = factory.apply(props.setId(key));
		Registry.register(BuiltInRegistries.ITEM, key, item);
		ALL.add(item);
		return item;
	}
}

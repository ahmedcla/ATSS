package com.elementalarsenal;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class ElementalArsenal implements ModInitializer {
	public static final String MOD_ID = "elementalarsenal";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModItems.init();
		ArsenalEvents.init();
	}
}

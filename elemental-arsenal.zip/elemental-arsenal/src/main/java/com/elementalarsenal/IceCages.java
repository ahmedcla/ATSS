package com.elementalarsenal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Temporary shell of ice built around a frozen entity. The blocks are removed again
 * after a short time (or when the server stops).
 */
public final class IceCages {
	private IceCages() {
	}

	private static final int LIFETIME_TICKS = 50;
	private static final int MAX_CELLS = 500;

	private static final class Cage {
		final ServerLevel level;
		final List<BlockPos> cells;
		int ticksLeft;

		Cage(ServerLevel level, List<BlockPos> cells, int ticksLeft) {
			this.level = level;
			this.cells = cells;
			this.ticksLeft = ticksLeft;
		}
	}

	private static final List<Cage> CAGES = new ArrayList<>();

	public static void build(ServerLevel level, LivingEntity target, LivingEntity attacker) {
		AABB box = target.getBoundingBox();
		int minX = Mth.floor(box.minX) - 1;
		int maxX = Mth.floor(box.maxX - 1.0E-6) + 1;
		int minY = Mth.floor(box.minY) - 1;
		int maxY = Mth.floor(box.maxY - 1.0E-6) + 1;
		int minZ = Mth.floor(box.minZ) - 1;
		int maxZ = Mth.floor(box.maxZ - 1.0E-6) + 1;

		long total = (long) (maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1);
		if (total > MAX_CELLS) {
			return;
		}

		AABB attackerBox = attacker.getBoundingBox();
		BlockState ice = Blocks.ICE.defaultBlockState();
		List<BlockPos> placed = new ArrayList<>();

		for (int x = minX; x <= maxX; x++) {
			for (int y = minY; y <= maxY; y++) {
				for (int z = minZ; z <= maxZ; z++) {
					boolean onShell = x == minX || x == maxX || y == minY || y == maxY || z == minZ || z == maxZ;
					if (!onShell) {
						continue;
					}
					BlockPos pos = new BlockPos(x, y, z);
					if (!level.hasChunkAt(pos)) {
						continue;
					}
					if (!level.getBlockState(pos).isAir()) {
						continue;
					}
					// never trap the attacker inside the ice
					if (attackerBox.intersects(new AABB(pos))) {
						continue;
					}
					level.setBlock(pos, ice, 3);
					placed.add(pos);
				}
			}
		}

		if (!placed.isEmpty()) {
			CAGES.add(new Cage(level, placed, LIFETIME_TICKS));
			level.sendParticles(ParticleTypes.SNOWFLAKE,
					target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
					40, 0.6, 0.6, 0.6, 0.05);
		}
	}

	public static void tick() {
		if (CAGES.isEmpty()) {
			return;
		}
		Iterator<Cage> it = CAGES.iterator();
		while (it.hasNext()) {
			Cage cage = it.next();
			cage.ticksLeft--;
			if (cage.ticksLeft <= 0) {
				release(cage);
				it.remove();
			}
		}
	}

	public static void clearAll() {
		for (Cage cage : CAGES) {
			release(cage);
		}
		CAGES.clear();
	}

	private static void release(Cage cage) {
		BlockState air = Blocks.AIR.defaultBlockState();
		for (BlockPos pos : cage.cells) {
			if (!cage.level.hasChunkAt(pos)) {
				continue;
			}
			BlockState state = cage.level.getBlockState(pos);
			// water appears when somebody breaks the ice by hand, clean that up too
			if (state.is(Blocks.ICE) || state.is(Blocks.WATER)) {
				cage.level.setBlock(pos, air, 3);
				cage.level.sendParticles(ParticleTypes.SNOWFLAKE,
						pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
						2, 0.3, 0.3, 0.3, 0.02);
			}
		}
	}
}

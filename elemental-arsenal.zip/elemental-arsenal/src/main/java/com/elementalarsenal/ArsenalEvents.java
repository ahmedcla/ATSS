package com.elementalarsenal;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class ArsenalEvents {
	private ArsenalEvents() {
	}

	/** Extra damage dealt by the fire sword against ice armor and by the ice sword against fire armor (12 -> 15). */
	private static final float COUNTER_BONUS_DAMAGE = 3.0F;

	/** Prevents the bonus hit from triggering the sword effects again. */
	private static boolean applyingBonus = false;

	public static void init() {
		ServerLivingEntityEvents.ALLOW_DAMAGE.register(ArsenalEvents::allowDamage);
		ServerLivingEntityEvents.AFTER_DAMAGE.register(ArsenalEvents::afterDamage);
		ServerTickEvents.END_SERVER_TICK.register(ArsenalEvents::onServerTick);
		ServerLifecycleEvents.SERVER_STOPPING.register(server -> IceCages.clearAll());
	}

	// ------------------------------------------------------------------ damage immunities
	private static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
		// Wind boots: no fall damage
		if (source.is(DamageTypeTags.IS_FALL) && entity.getItemBySlot(EquipmentSlot.FEET).is(ModItems.WIND_BOOTS)) {
			return false;
		}
		// Ice armor (full set): immune to freezing damage
		if (source.is(DamageTypeTags.IS_FREEZING) && hasFullSet(entity, ModItems.ICE_SET)) {
			return false;
		}
		return true;
	}

	// ------------------------------------------------------------------ sword effects
	private static void afterDamage(LivingEntity target, DamageSource source, float baseDamageTaken, float damageTaken, boolean blocked) {
		if (applyingBonus || blocked) {
			return;
		}
		Entity attackerEntity = source.getEntity();
		if (!(attackerEntity instanceof LivingEntity attacker)) {
			return;
		}
		// melee only (not arrows, tridents, magic ...)
		if (source.getDirectEntity() != attacker) {
			return;
		}
		if (!(target.level() instanceof ServerLevel level)) {
			return;
		}

		ItemStack weapon = attacker.getMainHandItem();

		if (weapon.is(ModItems.FIRE_SWORD)) {
			fireHit(level, attacker, target, source);
		} else if (weapon.is(ModItems.ICE_SWORD)) {
			iceHit(level, attacker, target, source);
		} else if (weapon.is(ModItems.WIND_SWORD)) {
			windHit(level, attacker, target);
		} else if (weapon.is(ModItems.EARTH_SWORD)) {
			earthHit(level, target);
		}
	}

	private static void fireHit(ServerLevel level, LivingEntity attacker, LivingEntity target, DamageSource source) {
		// Fire Aspect V = 4 seconds per level = 20 seconds
		target.igniteForSeconds(20.0F);
		level.sendParticles(ParticleTypes.FLAME,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				25, 0.4, 0.5, 0.4, 0.05);
		level.sendParticles(ParticleTypes.LAVA,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				6, 0.3, 0.4, 0.3, 0.0);

		if (wearsAnyPiece(target, ModItems.ICE_SET)) {
			applyBonusDamage(level, target, source);
		}
	}

	private static void iceHit(ServerLevel level, LivingEntity attacker, LivingEntity target, DamageSource source) {
		// bonus damage first, so a killed target does not get an ice shell
		if (wearsAnyPiece(target, ModItems.FIRE_SET)) {
			applyBonusDamage(level, target, source);
		}
		if (!target.isAlive()) {
			return;
		}

		// Ice armor wearers are immune to the freeze
		if (hasFullSet(target, ModItems.ICE_SET)) {
			level.sendParticles(ParticleTypes.SNOWFLAKE,
					target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
					10, 0.4, 0.5, 0.4, 0.02);
			return;
		}

		// slowness + frozen-screen effect + shell of ice around the target
		target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 4, false, true, true));
		target.setTicksFrozen(target.getTicksRequiredToFreeze() + 80);
		IceCages.build(level, target, attacker);
	}

	private static void windHit(ServerLevel level, LivingEntity attacker, LivingEntity target) {
		// Knockback III = 3 * 0.5 push strength, same direction vanilla uses for the attacker's facing
		double yaw = attacker.getYRot() * (Math.PI / 180.0);
		target.knockback(1.5F, Math.sin(yaw), -Math.cos(yaw));
		level.sendParticles(ParticleTypes.CLOUD,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				20, 0.4, 0.4, 0.4, 0.08);
	}

	private static void earthHit(ServerLevel level, LivingEntity target) {
		level.sendParticles(ParticleTypes.POOF,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				12, 0.4, 0.4, 0.4, 0.03);
		level.sendParticles(ParticleTypes.HAPPY_VILLAGER,
				target.getX(), target.getY() + target.getBbHeight() * 0.5, target.getZ(),
				8, 0.5, 0.5, 0.5, 0.0);
	}

	private static void applyBonusDamage(ServerLevel level, LivingEntity target, DamageSource source) {
		applyingBonus = true;
		try {
			target.invulnerableTime = 0;
			target.hurtServer(level, source, COUNTER_BONUS_DAMAGE);
		} finally {
			applyingBonus = false;
		}
	}

	// ------------------------------------------------------------------ passive perks (every 5 ticks)
	private static void onServerTick(MinecraftServer server) {
		IceCages.tick();
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (player.tickCount % 5 == 0) {
				applyPerks(player);
			}
		}
	}

	private static void applyPerks(ServerPlayer player) {
		// Earth sword: Strength II while held
		if (player.getMainHandItem().is(ModItems.EARTH_SWORD) || player.getOffhandItem().is(ModItems.EARTH_SWORD)) {
			player.addEffect(new MobEffectInstance(MobEffects.STRENGTH, 30, 1, true, false, false));
		}
		// Fire armor (full set): Fire Resistance
		if (hasFullSet(player, ModItems.FIRE_SET)) {
			player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 40, 0, true, false, false));
		}
		// Earth armor (full set): Resistance II
		if (hasFullSet(player, ModItems.EARTH_SET)) {
			player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 40, 1, true, false, false));
		}
		// Ice armor (full set): never frozen (powder snow, ice sword)
		if (hasFullSet(player, ModItems.ICE_SET) && player.getTicksFrozen() > 0) {
			player.setTicksFrozen(0);
		}
	}

	// ------------------------------------------------------------------ helpers
	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
	};

	/** set = {helmet, chestplate, leggings, boots} */
	private static boolean hasFullSet(LivingEntity entity, Item[] set) {
		for (int i = 0; i < ARMOR_SLOTS.length; i++) {
			if (!entity.getItemBySlot(ARMOR_SLOTS[i]).is(set[i])) {
				return false;
			}
		}
		return true;
	}

	private static boolean wearsAnyPiece(LivingEntity entity, Item[] set) {
		for (int i = 0; i < ARMOR_SLOTS.length; i++) {
			if (entity.getItemBySlot(ARMOR_SLOTS[i]).is(set[i])) {
				return true;
			}
		}
		return false;
	}
}

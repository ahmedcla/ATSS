package com.elementalarsenal;

import java.util.Map;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class ModMaterials {
	private ModMaterials() {
	}

	/** Items that can repair the swords / armor in an anvil (see data/elementalarsenal/tags/item/repairs_arsenal.json). */
	public static final TagKey<Item> REPAIRS_ARSENAL = TagKey.create(Registries.ITEM, ElementalArsenal.id("repairs_arsenal"));

	/** Same durability multiplier as netherite armor. */
	public static final int ARMOR_DURABILITY = 37;

	/**
	 * Sword material. The attack damage bonus is 0 on purpose: the real damage comes from the
	 * value passed to Item.Properties#sword (11 + 1 base player damage = 12 total).
	 */
	public static final ToolMaterial SWORD_MATERIAL = new ToolMaterial(
			BlockTags.INCORRECT_FOR_NETHERITE_TOOL,
			2400,
			9.0F,
			0.0F,
			15,
			REPAIRS_ARSENAL
	);

	public static final ArmorMaterial FIRE_ARMOR = armor("fire");
	public static final ArmorMaterial ICE_ARMOR = armor("ice");
	public static final ArmorMaterial WIND_ARMOR = armor("wind");
	public static final ArmorMaterial EARTH_ARMOR = armor("earth");

	private static ArmorMaterial armor(String name) {
		ResourceKey<EquipmentAsset> assetKey = ResourceKey.create(EquipmentAssets.ROOT_ID, ElementalArsenal.id(name));
		return new ArmorMaterial(
				ARMOR_DURABILITY,
				Map.of(
						ArmorType.HELMET, 5,
						ArmorType.CHESTPLATE, 8,
						ArmorType.LEGGINGS, 6,
						ArmorType.BOOTS, 5
				),
				15,
				SoundEvents.ARMOR_EQUIP_NETHERITE,
				3.0F,
				0.1F,
				REPAIRS_ARSENAL,
				assetKey
		);
	}
}
